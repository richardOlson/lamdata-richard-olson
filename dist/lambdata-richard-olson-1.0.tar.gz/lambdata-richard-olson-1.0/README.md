# lamdata-richard-olson
